
public class Jur�dica extends Pessoa {
	String cnpj;
	String insEstadual;
	String insMunicipal;
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getInsEstadual() {
		return insEstadual;
	}
	public void setInsEstadual(String insEstadual) {
		this.insEstadual = insEstadual;
	}
	public String getInsMunicipal() {
		return insMunicipal;
	}
	public void setInsMunicipal(String insMunicipal) {
		this.insMunicipal = insMunicipal;
	}

}
