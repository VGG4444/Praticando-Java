

	public class CD extends Midia{
		int nMusicas;
		String tipo = "CD";

		public int getnMusicas() {
			return nMusicas;
		}

		public void setnMusicas(int nMusicas) {
			this.nMusicas = nMusicas;
		}
		public String getTipo() {
			return  tipo;
		}


	}


