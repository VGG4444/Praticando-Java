public class DVD extends Midia {
	int nFaixas;
	String tipo = "DVD";

	public int getnFaixas() {
		return nFaixas;
	}

	public void setnFaixas(int nFaixas) {
		this.nFaixas = nFaixas;
	}

	public String getTipo() {
		return tipo;
	}

}
