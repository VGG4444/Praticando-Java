
public class Assistente extends Funcionario {
	double salario = 1212;

}
