
public class Comissionado extends Funcionario {
}