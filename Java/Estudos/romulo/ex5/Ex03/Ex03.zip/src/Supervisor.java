
public class Supervisor extends Funcionario {
	double salario = 2424;

}
